import React from "react";

export default () => {
  return <h1>This is the campaign list page!!!</h1>;
};
